'use strict';
const tabsByNote=new Map();
chrome.runtime.onMessage.addListener((msg,sender)=>{if(msg?.type!=='meet-chat'||!sender.tab)return;const id='meet-'+Date.now();tabsByNote.set(id,{tabId:sender.tab.id,windowId:sender.tab.windowId});
 chrome.notifications.create(id,{type:'basic',iconUrl:'icon128.png',title:msg.title,message:msg.body||'',contextMessage:'點這裡切回 Meet 回覆',priority:2,requireInteraction:true});
 chrome.action.setBadgeText({text:'!'});chrome.action.setBadgeBackgroundColor({color:'#c4654e'})});
chrome.notifications.onClicked.addListener(id=>{const t=tabsByNote.get(id);if(t){chrome.windows.update(t.windowId,{focused:true});chrome.tabs.update(t.tabId,{active:true})}chrome.notifications.clear(id);chrome.action.setBadgeText({text:''})});
chrome.notifications.onClosed.addListener(id=>tabsByNote.delete(id));

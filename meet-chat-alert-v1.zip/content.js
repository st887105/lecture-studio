'use strict';
// 偵測 Meet 聊天室新訊息：聊天面板中每則訊息都帶有 data-message-id。
// 面板關閉時 Meet 只顯示小浮窗，另以聊天按鈕上的未讀提示作備援。
const seen=new Set();let armed=false;
function clean(t){return (t||'').replace(/\s+/g,' ').trim()}
function senderOf(el){let n=el;for(let i=0;i<6&&n;i++){n=n.parentElement;const name=n?.getAttribute?.('data-sender-name');if(name)return name;const first=n?.firstElementChild;if(first&&first!==el&&!first.querySelector('[data-message-id]')){const t=clean(first.innerText).split(' ')[0];if(t&&t.length<40)return t}}return ''}
function send(title,body){try{chrome.runtime.sendMessage({type:'meet-chat',title,body})}catch{}}
function scan(){for(const el of document.querySelectorAll('[data-message-id]')){const id=el.getAttribute('data-message-id');if(seen.has(id))continue;seen.add(id);if(!armed)continue;const text=clean(el.innerText);if(!text)continue;const who=senderOf(el);send(who?`${who} 在 Meet 傳來訊息`:'Meet 有新的聊天訊息',text.slice(0,180))}}
let unread=false;
function chatButtonUnread(){const b=[...document.querySelectorAll('button[aria-label]')].find(x=>/即時通訊|聊天|chat/i.test(x.getAttribute('aria-label')));if(!b)return false;return /未讀|new|unread/i.test(b.getAttribute('aria-label'))||!!b.querySelector('[class*="badge"],[data-badge]')}
new MutationObserver(()=>{scan();const u=chatButtonUnread();if(u&&!unread&&armed&&!document.querySelector('[data-message-id]'))send('Meet 有新的聊天訊息','請打開 Meet 聊天室查看（建議講課時保持聊天面板開啟，提醒會顯示內容）。');unread=u}).observe(document.documentElement,{childList:true,subtree:true,characterData:true});
scan();setTimeout(()=>{scan();armed=true},4000);

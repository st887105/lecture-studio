'use strict';
const defaults={character:'teacher',gesture:'auto',strength:1.2,name:'研習講師',position:'br',size:24,visible:true};
let settings={...defaults},activeTabs=new Set(),controllerId=null,controllerPort=null,jaw={value:0,time:0,live:false,demo:false};const ports=new Map();
const ready=chrome.storage.session.get(['settings','activeTabs','controllerId']).then(s=>{settings={...defaults,...s.settings};activeTabs=new Set(s.activeTabs||[]);controllerId=s.controllerId||null});
function persist(){return chrome.storage.session.set({settings,activeTabs:[...activeTabs],controllerId})}
function broadcast(message){for(const [p,tabId] of ports){if(tabId!==null&&!activeTabs.has(tabId))continue;try{p.postMessage(message)}catch{}}}
function patchSettings(input){for(const k of ['character','gesture','position']){const allowed={character:['teacher','onion'],gesture:['auto','neutral','explain','point'],position:['br','bl','tr','tl']}[k];if(allowed.includes(input[k]))settings[k]=input[k]}for(const k of ['size','strength']){const n=Number(input[k]);if(Number.isFinite(n))settings[k]=Math.max(k==='size'?12:.5,Math.min(k==='size'?32:1.8,n))}if(typeof input.name==='string')settings.name=input.name.slice(0,24);if(typeof input.visible==='boolean')settings.visible=input.visible;persist();broadcast({type:'settings',settings})}
async function inject(tabId){await chrome.scripting.executeScript({target:{tabId},files:['teaching-tools.js','character-painter.js','content.js']})}
chrome.action.onClicked.addListener(async tab=>{await ready;if(!tab.id||!/^https?:/.test(tab.url||'')){await chrome.action.setTitle({tabId:tab.id,title:'請在一般 http／https 網頁啟用；瀏覽器設定及內建 PDF 頁不支援。'});return}activeTabs.add(tab.id);await persist();try{try{await chrome.tabs.sendMessage(tab.id,{type:'show'})}catch{await inject(tab.id)}}catch(e){activeTabs.delete(tab.id);await persist();await chrome.action.setTitle({tabId:tab.id,title:'無法在此頁啟用：'+String(e.message).slice(0,100)})}});
// Same-origin navigation retains activeTab access. Cross-origin navigation does
// not; failing injection stops automatic activation until the user clicks again.
chrome.tabs.onUpdated.addListener(async(tabId,change)=>{await ready;if(change.status!=='complete'||!activeTabs.has(tabId))return;try{await chrome.tabs.sendMessage(tabId,{type:'ping'})}catch{try{await inject(tabId)}catch{activeTabs.delete(tabId);persist()}}});
chrome.tabs.onRemoved.addListener(tabId=>{activeTabs.delete(tabId);if(controllerId===tabId)controllerId=null;persist()});
chrome.runtime.onConnect.addListener(port=>{const ownPage=(port.sender?.url||'').split('#')[0],isController=port.name==='lecture-controller'&&ownPage===chrome.runtime.getURL('controller.html');
 if(isController){controllerPort=port;ready.then(()=>{try{port.postMessage({type:'settings',settings})}catch{}});port.onMessage.addListener(message=>{if(message.type==='jaw'){jaw={value:Math.max(0,Math.min(1,Number(message.value)||0)),time:Date.now(),live:!!message.live,demo:!!message.demo};broadcast({type:'jaw',jaw})}if(message.type==='settings')patchSettings(message.settings||{})});port.onDisconnect.addListener(()=>{if(controllerPort===port){controllerPort=null;jaw={value:0,time:Date.now(),live:false,demo:false};broadcast({type:'jaw',jaw})}});return}
 if(port.name!=='lecture-overlay'||!port.sender?.tab?.id)return;const tabId=port.sender.tab.id;ready.then(()=>{if(!activeTabs.has(tabId)){port.disconnect();return}ports.set(port,tabId);port.postMessage({type:'settings',settings});port.postMessage({type:'jaw',jaw})});port.onDisconnect.addListener(()=>ports.delete(port));
});
chrome.runtime.onMessage.addListener((message,sender,respond)=>{(async()=>{await ready;const tabId=sender.tab?.id;if(!tabId||!activeTabs.has(tabId))throw Error('請先點擊擴充功能圖示啟用此頁。');
 if(message.type==='settings'){patchSettings(message.settings||{});return{ok:true}}
 if(message.type==='controller'){if(controllerId){try{await chrome.tabs.update(controllerId,{active:true});return{ok:true}}catch{controllerId=null}}const tab=await chrome.tabs.create({url:chrome.runtime.getURL('controller.html')});controllerId=tab.id;persist();return{ok:true}}
 if(message.type==='zoom'){const current=await chrome.tabs.getZoom(tabId),next=message.action==='reset'?1:Math.max(.5,Math.min(3,current+(message.action==='in'?.25:-.25)));await chrome.tabs.setZoom(tabId,next);return{ok:true,zoom:next}}
 if(message.type==='disable'){activeTabs.delete(tabId);await persist();return{ok:true}}throw Error('不支援的操作。')
 })().then(respond,error=>respond({error:error.message}));return true});

# Third-party components

MediaPipe Tasks Vision 0.10.21 and Face Landmarker (float16 model, version 1), Google LLC / MediaPipe Authors. Licensed under Apache License 2.0; full terms in vendor/LICENSE-APACHE-2.0.txt. Vendor binaries and JS are unmodified.

Sources:
- https://github.com/google-ai-edge/mediapipe
- https://www.npmjs.com/package/@mediapipe/tasks-vision/v/0.10.21
- https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task

The included Apache license is the standard license text available locally; no new network download was used.
